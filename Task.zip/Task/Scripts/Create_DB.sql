CREATE DATABASE lendico_task_sourabh;
use lendico_task_sourabh;