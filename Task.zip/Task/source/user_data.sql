USE `lendico_task_sourabh`;
DROP TABLE IF EXISTS `user_data`;

CREATE TABLE `user_data` (
  `investor_id` varchar(255) DEFAULT NULL,
  `firstName` varchar(40) DEFAULT NULL,
  `lastName` varchar(40) DEFAULT NULL,
  `gender` varchar(2) DEFAULT NULL,
  `street` varchar(40) DEFAULT NULL,
  `streetNumber` varchar(20) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*
-- Date: 2018-03-02 13:16
*/
INSERT INTO `user_data` (`investor_id`,`firstName`,`lastName`,`gender`,`street`,`streetNumber`,`zip`) VALUES ('DE-38','Peter','Brett','m','SchwedenstraÃŸe','13','10153');
INSERT INTO `user_data` (`investor_id`,`firstName`,`lastName`,`gender`,`street`,`streetNumber`,`zip`) VALUES ('DE-233313','Britta','Haus','w','BadstraÃŸe','2','13351');
INSERT INTO `user_data` (`investor_id`,`firstName`,`lastName`,`gender`,`street`,`streetNumber`,`zip`) VALUES ('AT-9921','Hans','MÃ¼ller','m','SeestraÃŸe','114a','13057');
INSERT INTO `user_data` (`investor_id`,`firstName`,`lastName`,`gender`,`street`,`streetNumber`,`zip`) VALUES ('AT-23498','Anna','Wand','w','PankstraÃŸe','16','13211');
INSERT INTO `user_data` (`investor_id`,`firstName`,`lastName`,`gender`,`street`,`streetNumber`,`zip`) VALUES ('DE-43535','Frank','Lampe','m','Sonnenallee','8','10119');
INSERT INTO `user_data` (`investor_id`,`firstName`,`lastName`,`gender`,`street`,`streetNumber`,`zip`) VALUES ('DE-238260','Sebastian','Schmidt','m','Pappelallee','754','12043');

