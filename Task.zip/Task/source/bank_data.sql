
USE `lendico_task_sourabh`;
DROP TABLE IF EXISTS `bank_data`;

CREATE TABLE `bank_data` (
  `investor_id` varchar(255) DEFAULT NULL,
  `IBAN` varchar(40) DEFAULT NULL,
  `BIC` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*
-- Date: 2018-03-02 13:16
*/
INSERT INTO `bank_data` (`investor_id`,`IBAN`,`BIC`) VALUES ('DE-38','DE439530239023123','WELADZ231\r');
INSERT INTO `bank_data` (`investor_id`,`IBAN`,`BIC`) VALUES ('DE-233313','DE220993439347232','KLZ343ADEF\r');
INSERT INTO `bank_data` (`investor_id`,`IBAN`,`BIC`) VALUES ('AT-9921','AT054395834534542','ZYH3123BZ32\r');
INSERT INTO `bank_data` (`investor_id`,`IBAN`,`BIC`) VALUES ('AT-23498','AT9423424782412223','LKJH2323AS3\r');
INSERT INTO `bank_data` (`investor_id`,`IBAN`,`BIC`) VALUES ('DE-43535','DE092345743855454','BLN453254AS\r');
INSERT INTO `bank_data` (`investor_id`,`IBAN`,`BIC`) VALUES ('DE-238260','DE015458745435225','WELADE423\r');