USE `lendico_task_sourabh`;
DROP procedure IF EXISTS `usp_lendico_task_sourabh_report_investor`;

DELIMITER $$
USE `lendico_task_sourabh`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_lendico_task_sourabh_report_investor`(

IN in_Investor_ID varchar(100),
IN in_Report_DT DATE)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
SELECT 'An error has occurred, the stored procedure was terminated';
END;

IF NOT EXISTS( Select investor_id
 from bank_data where investor_id=in_Investor_ID) THEN
SELECT 'No such ID exists';

ELSE 

DROP TABLE IF EXISTS `report_investor`;
create table lendico_task_sourabh.report_investor(
report_date DATE,
investor_id varchar(100),
planned_total varchar(100),
received_total varchar(100),
planned_interest varchar(100),
received_interest varchar(100),
planned_principal varchar(100),
received_principal varchar(100),
planned_fee varchar(100),
paid_fee varchar(100),
name varchar(40),
street varchar(40),
streetNumber varchar(40),
zip varchar(40), 
IBAN varchar(40), 
BIC varchar(40)
);

insert into lendico_task_sourabh.report_investor(
report_date,
investor_id,
planned_total,
received_total,
planned_interest,
received_interest,
planned_principal,
received_principal,
planned_fee,
paid_fee,
name,
street,
streetNumber,
zip, 
IBAN, 
BIC
)
select null as report_date,
pl.investor_id,
cast(cast(pl.planned_total as decimal(10,2)) as char(100)) as planned_total, 
cast(cast(rec.RECEIVED_INTEREST+rec.RECEIVED_PRINCIPAL-rec.PAID_FEE as decimal(10,2)) as char(100)) as RECEIVED_total,
cast(cast(pl.planned_interest as decimal(10,2)) as char(100)) as planned_interest, 
cast(cast(rec.RECEIVED_INTEREST as decimal(10,2)) as char(100)) as RECEIVED_INTEREST, 
cast(cast(pl.planned_principal as decimal(10,2)) as char(100)) as planned_principal, 
cast(cast(rec.RECEIVED_PRINCIPAL as decimal(10,2)) as char(100)) as RECEIVED_PRINCIPAL,
cast(cast(pl.planned_fee as decimal(10,2)) as char(100)) as planned_fee, 
cast(cast(rec.PAID_FEE as decimal(10,2)) as char(100)) as PAID_FEE,
concat(firstName,' ',lastName)as Name, street, streetNumber, zip, IBAN, BIC 
from lendico_task_sourabh.user_data ud 
INNER JOIN lendico_task_sourabh.bank_data bd on bd.investor_id=ud.investor_id
INNER JOIN 
(select tp.investor_id as investor_id,sum(tp.planned_principal) as planned_principal,
sum(tp.planned_interest)as planned_interest,sum(tp.planned_fee)as planned_fee,
sum(tp.planned_total)as planned_total
from
(select pe.plan_id,p.investor_id as investor_id,p.investment_id as investment_id,sum(pe.principal)as planned_principal,
sum(pe.interest)as planned_interest,sum(pe.fee)as planned_fee,sum(pe.total)as planned_total
from lendico_task_sourabh.plan p inner join lendico_task_sourabh.plan_entries pe on pe.plan_id=p.plan_id
group by investor_id,investment_id)tp
group by tp.investor_id)pl
on pl.investor_id=bd.investor_id
INNER JOIN (
select dt.investor_id as investor_id ,SUM(dt.PRINCIPAL_amount)as RECEIVED_PRINCIPAL,SUM(dt.INTEREST_amount)as RECEIVED_INTEREST,
SUM(dt.FEE_amount)as PAID_FEE,dt.latest_transaction_date as latest_transaction_date
from
(select investor_id,investment_id,
sum(case when item_type='PRINCIPAL'
then amount end)
 AS PRINCIPAL_amount,
 sum(case when item_type='INTEREST'
then amount end)
 AS INTEREST_amount,
 sum(case when item_type='INVESTOR_FEE'
then amount end) AS FEE_amount,
max(cleared_at)as latest_transaction_date
 from lendico_task_sourabh.cashflow
  group by investor_id,investment_id)dt 
  GROUP BY dt.investor_id
  )rec on rec.investor_id=pl.investor_id
where rec.investor_id=in_Investor_ID and DATE(rec.latest_transaction_date)<=in_Report_DT;

UPDATE lendico_task_sourabh.report_investor SET report_date=in_Report_DT;

Select 'report_date','investor_id','planned_total','received_total','planned_interest','received_interest','planned_principal','received_principal','planned_fee','paid_fee','name','street','streetNumber','zip', 'IBAN','BIC'
UNION ALL
SELECT report_date,investor_id,planned_total,received_total,planned_interest ,received_interest,planned_principal,received_principal,planned_fee,paid_fee,name,street,streetNumber,zip,IBAN,BIC
from report_investor
into OUTFILE "C:/report_investor.csv"
FIELDS TERMINATED BY ','
ENCLOSED BY '"';
END IF;
END;$$

DELIMITER ;

